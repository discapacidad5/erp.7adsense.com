Logo Font By 

http://fontfabric.com/intro-free-font/