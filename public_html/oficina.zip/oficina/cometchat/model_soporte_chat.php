<?php


	class Red_chat{

	
		function red_a_red(){
			setcookie("red1","1", time() + (86400)*30, "/");
		}
		
		function red_soporte(){
			setcookie("red1","2", time() + (86400)*30, "/");
		}
		function soporte_red(){
			setcookie("red1","3", time() + (86400)*30, "/");
		}
	
	
	}
		
		
		
	
		
	


	
	
