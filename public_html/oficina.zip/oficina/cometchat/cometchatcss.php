<?php

include_once(dirname(__FILE__).DIRECTORY_SEPARATOR.'css.php');