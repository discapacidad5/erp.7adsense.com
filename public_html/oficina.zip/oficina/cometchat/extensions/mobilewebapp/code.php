<?php
$extensioninfo = array('mobilewebapp','Mobile Webapp');