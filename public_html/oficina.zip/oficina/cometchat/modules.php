<?php

include_once(dirname(__FILE__).DIRECTORY_SEPARATOR."cometchat_init.php"); 
